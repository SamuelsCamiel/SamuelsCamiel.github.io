let stars = [];
let trees = [];
let birds = [];
let time = 0;
let groundHeight;
let touchedStars = 0;
const maxTouches = 5;
let starsToReset = [];
let resetDelay = 500;
let lastResetTime = 0;
let resetInProgress = false;
let starSwapTime = 20000;
let lastSwapTime = 0;


let moon = {
  x: 0,
  y: 100,
  size: 80,
  speed: 0.3,
  color: [240, 240, 200],
  glow: 50
};

function setup() {
  createCanvas(windowWidth, windowHeight);
  groundHeight = height * 0.3;


  let starCount = 20;
  for (let i = 0; i < starCount; i++) {
    stars.push(createRandomStar());
  }

 
  let treeCount = 7;
  let spacing = width / treeCount;
  for (let i = 0; i < treeCount; i++) {
    trees.push({
      x: spacing * i + spacing / 2,
      y: height - groundHeight + 20,
      size: random(120, 180),
      swayOffset: random(1000)
    });
  }

  
  let birdCount = 5;
  for (let i = 0; i < birdCount; i++) {
    birds.push({
      x: random(width),
      y: random(height * 0.4),
      speed: random(0.5, 1.5),
      wingAngle: 0,
      wingSpeed: random(0.05, 0.1)
    });
  }
}

function draw() {
    stroke(0);
  strokeWeight(0);
  background(20, 30, 60);

  //Maankleur laten pulseren
  let r = 200 + sin(frameCount * 0.01) * 40;
  let g = 200 + sin(frameCount * 0.008) * 30;
  let b = 180 + sin(frameCount * 0.009) * 20;
  moon.color = [r, g, b];

  // Maan tekenen
  drawingContext.shadowBlur = moon.glow;
  drawingContext.shadowColor = color(moon.color);
  fill(moon.color);
  ellipse(moon.x, moon.y, moon.size);
  drawingContext.shadowBlur = 0;


  moon.x += moon.speed;
  if (moon.x > width + moon.size / 2) {
    moon.x = -moon.size / 2;
  }

 
  fill(50, 30, 20);
  rect(0, height - groundHeight, width, groundHeight);

  // sterren teken
  for (let star of stars) {
    let elapsed = millis() - star.touchedTime;

    if (star.isRotating && elapsed > 5000) {
      star.isRotating = false;
      star.size = random(6, 14);
      star.color = star.defaultColor;
    }

    push();
    translate(star.x, star.y);
    if (star.isRotating) {
      star.angle += 0.1;
      rotate(star.angle);
    }

    let twinkle = sin(frameCount * 0.05 + star.x) * 20;
    let r = constrain(star.color[0] + twinkle, 100, 255);
    let g = constrain(star.color[1] + twinkle, 100, 255);
    let b = constrain(star.color[2] + twinkle, 100, 255);
    fill(r, g, b);
    noStroke();
    drawStar(0, 0, star.size, star.size * 2, 5);
    pop();
  }

  for (let tree of trees) {
    let sway = sin(time + tree.swayOffset) * 5;
    drawTree(tree.x + sway, tree.y, tree.size);
  }

  time += 0.02;

  
  if (millis() - lastSwapTime >= starSwapTime) {
    swapStars();
    lastSwapTime = millis();
  }

  
  if (starsToReset.length > 0 && millis() - lastResetTime >= resetDelay && !resetInProgress) {
    let star = starsToReset.shift();
    resetStar(star);
    lastResetTime = millis();
  }

 
  for (let bird of birds) {
    bird.x += bird.speed;
    bird.wingAngle += bird.wingSpeed;

    if (bird.x > width + 20) {
      bird.x = -20;
      bird.y = random(height * 0.4);
    }

    drawBird(bird.x, bird.y, sin(bird.wingAngle) * 5);
  }
}


function drawTree(x, y, size) {
    stroke(0);
  strokeWeight(0);
  fill(101, 67, 33);
  rect(x - size * 0.1, y, size * 0.2, size * 0.5);
  fill(34, 139, 34);
  triangle(x - size * 0.5, y, x + size * 0.5, y, x, y - size);
}


function drawStar(x, y, radius1, radius2, npoints) {
  let angle = TWO_PI / npoints;
  let halfAngle = angle / 2.0;
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius2;
    let sy = y + sin(a) * radius2;
    vertex(sx, sy);
    sx = x + cos(a + halfAngle) * radius1;
    sy = y + sin(a + halfAngle) * radius1;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}


function drawBird(x, y, wingOffset) {
  stroke(255);
  strokeWeight(2);
  noFill();
  beginShape();
  vertex(x - 10, y + wingOffset);
  vertex(x, y);
  vertex(x + 10, y + wingOffset);
  endShape();
}

function resetStar(star) {
  star.size = random(6, 14);
  star.color = star.defaultColor;
  star.isRotating = false;
  star.touchedTime = 0;
  star.angle = 0;
}

function createRandomStar() {
  let star = {
    x: random(width),
    y: random(height - groundHeight),
    size: random(6, 14),
    color: [255, 255, 255],
    defaultColor: [255, 255, 255],
    touchedTime: 0,
    isRotating: false,
    angle: 0
  };

  for (let otherStar of stars) {
    let d = dist(star.x, star.y, otherStar.x, otherStar.y);
    if (d < star.size + otherStar.size) {
      return createRandomStar();
    }
  }

  return star;
}

function swapStars() {
  for (let star of stars) {
    let newX = random(width);
    let newY = random(height - groundHeight);

    for (let otherStar of stars) {
      let d = dist(newX, newY, otherStar.x, otherStar.y);
      if (d < star.size + otherStar.size) {
        newX = random(width);
        newY = random(height - groundHeight);
        break;
      }
    }

    star.x = newX;
    star.y = newY;
  }
}

function changeStar(x, y) {
  if (touchedStars >= maxTouches) {
    for (let star of stars) {
      if (star.isRotating) {
        starsToReset.push(star);
      }
    }
    touchedStars = 0;
    resetInProgress = true;
    return;
  }

  for (let star of stars) {
    let d = dist(x, y, star.x, star.y);
    if (d < star.size * 2 && !star.isRotating) {
      star.size = random(10, 20);
      star.color = [random(100, 255), random(100, 255), random(100, 255)];
      star.touchedTime = millis();
      star.isRotating = true;
      star.angle = 0;
      touchedStars++;

      if (touchedStars >= maxTouches) {
        resetInProgress = true;
        for (let s of stars) {
          if (s.isRotating) {
            starsToReset.push(s);
          }
        }
      }
      return;
    }
  }
}

function mousePressed() {
  changeStar(mouseX, mouseY);
}

function touchStarted() {
  changeStar(touches[0].x, touches[0].y);
}
